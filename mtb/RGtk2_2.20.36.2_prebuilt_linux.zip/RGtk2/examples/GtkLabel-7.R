## RGtk2 has no support for GMarkup
